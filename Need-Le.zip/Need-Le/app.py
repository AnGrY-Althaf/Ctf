from flask import Flask, render_template, request, g, session
import sqlite3
import re
from functools import wraps
import time

app = Flask(__name__)
app.secret_key = 'your_secure_secret_key_here'

# Rate limiting decorator
def rate_limit(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        ip = request.remote_addr
        current_time = time.time()
        
        # Get failed attempts from session
        failed_attempts = session.get('failed_attempts', {})
        if ip in failed_attempts:
            if current_time - failed_attempts[ip]['timestamp'] < 30:  # 30 second cooldown
                if failed_attempts[ip]['count'] >= 5:  # Max 5 attempts
                    return 'Too many attempts. Try again later.', 429
            else:
                failed_attempts[ip] = {'count': 0, 'timestamp': current_time}
        
        return f(*args, **kwargs)
    return decorated_function

# WAF filter (intentionally bypassable but requires effort)
def waf_filter(input_string):
    # Blacklist of SQL injection patterns
    blacklist = [
        r'UNION\s+SELECT',
        r'--',
        r'#',
        r';',
        r'DROP\s+TABLE',
        r'DELETE\s+FROM',
        r'INSERT\s+INTO',
        r'SLEEP\s*\(',
        r'BENCHMARK\s*\(',
        r'information_schema',
        r'\/\*.*?\*\/',  # Block comments
        r'OR\s+1\s*=\s*1',  # Common tautologies
        r'OR\s+\'1\'\s*=\s*\'1\'',
        r'AND\s+1\s*=\s*1',
        r'AND\s+\'1\'\s*=\s*\'1\''
    ]
    
    # Convert to lowercase for case-insensitive matching
    input_lower = input_string.lower()
    
    # Check against blacklist
    for pattern in blacklist:
        if re.search(pattern.lower(), input_lower):
            return True
    return False

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect('database.db')
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        # Create tables if they don't exist
        db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL,
                access_level INTEGER NOT NULL DEFAULT 0
            )
        ''')
        
        # Insert sample data
        try:
            db.execute("INSERT OR IGNORE INTO users (username, password, role, access_level) VALUES (?, ?, ?, ?)", 
                      ('admin', 'supersecret123', 'admin', 100))
            db.execute("INSERT OR IGNORE INTO users (username, password, role, access_level) VALUES (?, ?, ?, ?)", 
                      ('user', 'userpass123', 'user', 1))
            db.commit()
        except sqlite3.IntegrityError:
            pass

@app.before_request
def before_request():
    init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
@rate_limit
def login():
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        
        # First layer: WAF filter
        if waf_filter(username) or waf_filter(password):
            session['failed_attempts'] = session.get('failed_attempts', {})
            session['failed_attempts'][request.remote_addr] = {
                'count': session['failed_attempts'].get(request.remote_addr, {}).get('count', 0) + 1,
                'timestamp': time.time()
            }
            return render_template('waf.html'), 403

        # Vulnerable query (intentionally unsafe - part of the challenge)
        query = f"SELECT username, role, access_level FROM users WHERE username='{username}' AND password='{password}' AND role != 'admin'"
        
        try:
            cur = get_db().cursor()
            cur.execute(query)
            user = cur.fetchone()
            
            if user:
                return render_template('user.html', username=user[0], role=user[1], access_level=user[2])
            else:
                return "Invalid credentials"
        except sqlite3.Error as e:
            return "Database error occurred"

    return render_template('login.html')

@app.route('/admin', methods=['GET', 'POST'])
@rate_limit
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        
        # Apply WAF filter
        if waf_filter(username) or waf_filter(password):
            return render_template('waf_block.html'), 403

        # Vulnerable query with role check (intentionally unsafe - part of the challenge)
        query = f"SELECT username, role, access_level FROM users WHERE username='{username}' AND password='{password}' AND role='admin' AND access_level >= 100"
        
        try:
            cur = get_db().cursor()
            cur.execute(query)
            admin = cur.fetchone()
            
            if admin:
                # Flag for successful admin access
                return render_template('admin.html', flag="Inj3cTed{ByP4ss_W4F_4nd_RB4C}")
            else:
                return "Invalid admin credentials"
        except sqlite3.Error as e:
            return "Database error occurred"

    return render_template('admin_login.html')

if __name__ == '__main__':
    app.run(debug=False)  # Disable debug mode in production